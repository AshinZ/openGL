	CSC3260 Assignment 1 Keyboard and Mouse Events 

Name:  荀正
Student ID: 161810329

Demo procedure:
	Key "p": turn on the light;
	Key "b": turn off the light;
	Key "c": turn on the tv;
	Key "o": turn off the tv;
	Key "k": lift arm;
	Key "l": down arm;
	Key "f": enlarge ball;
	Key "g": narrow ball
	Key "a": people left;
	Key "s": people backward ;
	Key "w": people forward;
	Key "d": people right;
	Key "h": ball move;
	Key "n": ornament rotate ;
	Key "up":camera forward
	Key"down":camera backward
	Key"left":camera left
	Key"right":camera right
	Key "Esc": Exit
	Mouse_Left_Move:change angle of view

